// Script principal da página
window.addEventListener("load", function () {
  // Código específico para a página principal, não relacionado ao carrossel
  console.log("Página carregada com sucesso!");
}); 